CHALK & SLATE - example theme for Wireframe Saboteur
====================================================

A complete working theme in 88 images. It exists so you can take it apart.

THE SHORT VERSION
  1. Unzip this folder.
  2. Open texture.json. Change "id" and "name".
  3. Redraw any PNG you like, keeping its filename and pixel size.
  4. Zip the folder back up, with texture.json inside.
  5. In the game: Options > Themes > add a theme pack.

WHY SO FEW FILES
  "labels": true tells the game to write the piece designations itself. You
  supply one blank per piece type; the game writes A7, B3, C2 on top.

  Without it you would be drawing 174 numbered pieces by hand.

YOU CAN GO SMALLER
  Only texture.json is required. Everything else falls back to the game's own
  art. Four images - one A, one B each way, one C, in a single color - is a
  real, valid, importable theme. Build it up in passes.

THE ONE DESIGN RULE
  The designation is drawn over the middle of your blank. Keep the center
  fairly quiet. Notice that the blanks here use corner ticks and a rim band
  rather than a centered motif - that is why.

  Set "label_color" to something that reads against your art.

WANT TO DRAW THE NUMBERS YOURSELF?
  Supply the numbered file and it wins. blue_A7.png beats blue_A.png, and no
  label is drawn over it. Mix freely. Set "labels": false to turn the feature
  off and supply all 174 numbered files.

WHAT IS IN HERE, PER COLOR
  pieces/COLOR_A.png                   128 x 128
  pieces/COLOR_B_vertical.png          128 x 256
  pieces/COLOR_B_horizontal.png        256 x 128
  pieces/COLOR_C.png                   256 x 256
  pieces/general_COLOR.png             128 x 128
  pieces/objective_COLOR.png           128 x 128
  pieces/tray/tray_COLOR_A.png         128 x 128
  pieces/tray/tray_COLOR_B.png         128 x 256
  pieces/tray/tray_COLOR_C.png         256 x 256
  pieces/tray/tray_COLOR_General.png   128 x 128
  pieces/tray/tray_COLOR_Objective.png 128 x 128

  Colors: blue red green yellow magenta lavender

ALSO
  16 saboteur backs (back_*.png) - not per color, never labeled
  6 board halves (board/board_half_COLOR.png) - 1392 x 632, optional

RULES
  PNG only. SVG is skipped.
  Piece designations are fixed. Never renumber them.
  Keep the S readable on the saboteur backs.
  Do not move the board grid: 1152 x 512 starting 120 px in from left and top.

The full guide is in the game: Make Your Own > Make Your Own Theme.
